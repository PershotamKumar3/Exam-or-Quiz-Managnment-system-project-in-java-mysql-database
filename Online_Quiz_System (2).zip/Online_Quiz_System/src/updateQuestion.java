
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import online_quiz_system.Online_Quiz_System;


/**
 *
 * @author HP
 */
public class updateQuestion extends javax.swing.JFrame {

    /**
     * Creates new form updateQuestion
     */
    public updateQuestion() {
        initComponents();
    }

       
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        Uid = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        UQ = new javax.swing.JTextField();
        UO1 = new javax.swing.JTextField();
        UO2 = new javax.swing.JTextField();
        UO3 = new javax.swing.JTextField();
        UO4 = new javax.swing.JTextField();
        UA = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        E1 = new javax.swing.JRadioButton();
        M2 = new javax.swing.JRadioButton();
        H3 = new javax.swing.JRadioButton();
        jLabel13 = new javax.swing.JLabel();
        diffLvl = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAlwaysOnTop(true);
        setLocation(new java.awt.Point(150, 183));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 84));

        jLabel2.setFont(new java.awt.Font("Algerian", 1, 25)); // NOI18N
        jLabel2.setText("update question");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(69, 0, 263, 84));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Close_1.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(958, 15, 70, 60));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 1066, 10));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel3.setText("Question ID");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel4.setText("Question :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 170, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel5.setText("Option 1");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 220, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel6.setText("Option 2");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel7.setText("Option 3");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 300, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel8.setText("Option 4");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 340, -1, -1));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jButton2.setText("seach");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 120, 130, -1));

        Uid.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        getContentPane().add(Uid, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, 90, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel9.setText("Answer ");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 380, -1, -1));

        UQ.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        UQ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UQActionPerformed(evt);
            }
        });
        getContentPane().add(UQ, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 160, 750, 40));

        UO1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(UO1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 220, 750, 30));

        UO2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(UO2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 260, 750, 30));

        UO3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(UO3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 300, 750, 30));

        UO4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(UO4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 340, 750, 30));

        UA.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(UA, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 380, 750, 30));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/save_1.png"))); // NOI18N
        jButton3.setText("Update");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 490, 140, 40));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/clear.png"))); // NOI18N
        jButton4.setText("clear");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 490, 120, 40));
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        E1.setFont(new java.awt.Font("Tahoma", 1, 19)); // NOI18N
        E1.setText("Easy");
        E1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                E1ActionPerformed(evt);
            }
        });
        getContentPane().add(E1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 430, -1, -1));

        M2.setFont(new java.awt.Font("Tahoma", 1, 19)); // NOI18N
        M2.setText("Medium");
        M2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                M2ActionPerformed(evt);
            }
        });
        getContentPane().add(M2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 430, -1, -1));

        H3.setFont(new java.awt.Font("Tahoma", 1, 19)); // NOI18N
        H3.setForeground(new java.awt.Color(51, 51, 51));
        H3.setText("Hard");
        H3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                H3ActionPerformed(evt);
            }
        });
        getContentPane().add(H3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 430, 90, 30));

        jLabel13.setFont(new java.awt.Font("Sylfaen", 1, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 51, 51));
        jLabel13.setText("Diffi Lvl:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 430, -1, -1));

        diffLvl.setFont(new java.awt.Font("Sylfaen", 1, 24)); // NOI18N
        diffLvl.setForeground(new java.awt.Color(51, 51, 51));
        diffLvl.setText("type");
        getContentPane().add(diffLvl, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 430, -1, -1));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/home page (1).png"))); // NOI18N
        jLabel11.setText("jLabel11");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1070, 540));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        adminhome.open=0;
        setVisible(false);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
  String diff;
        Online_Quiz_System db = new Online_Quiz_System();
        ResultSet rs;
        rs = db.upquestion(Uid.getText());
        try {
            if(rs.next()){
                diff = (rs.getString("type"));
                if(  "1".equals(diff)){
            diffLvl.setText("Easy");
        }else if("2".equals(diff)){
            diffLvl.setText("Medium");
        }else if("3".equals(diff)){
            diffLvl.setText("Hard");
        }
             UQ.setText(rs.getString("Q"));
         UO1.setText(rs.getString("op_1"));
          UO2.setText(rs.getString("op_2"));
        UO3.setText(rs.getString("op_3"));
        UO4.setText(rs.getString("op_4"));
        UA.setText(rs.getString("A_Q1"));
        
        
            
            }
        } catch (SQLException ex) {
            Logger.getLogger(updateQuestion.class.getName()).log(Level.SEVERE, null, ex);
        }
      
         String type;
        if (E1.isSelected()) {
            type = "1";
        } else if (M2.isSelected()) {
            type = "2";
        } else {
            type = "3";
       
        }

//String id = Uid.getText();
//Online_Quiz_System db = new Online_Quiz_System();
//
//try {
//    // Convert the question ID to an integer
//    int questionIdToSearch = Integer.parseInt(id);
//
//    // Call the method to retrieve the question details
//    ResultSet rs = db.upquestion(id);
//
//    try {
//        if (rs.next()) {
//            // Retrieve data from the result set and display it in your UI fields
//            UQ.setText(rs.getString("Q"));
//            UO1.setText(rs.getString("Op_1"));
//            UO2.setText(rs.getString("Op_2"));
//            UO3.setText(rs.getString("Op_3"));
//            UO4.setText(rs.getString("Op_4"));
//            UA.setText(rs.getString("A_Q1"));
//            
//          
//            
//        } else {
//            // Display a message if the ID does not exist
//            JFrame ns = new JFrame();
//            ns.setAlwaysOnTop(true);
//            JOptionPane.showMessageDialog(ns, "ID Does Not Exist");
//        }
//    } catch (SQLException ex) {
//        Logger.getLogger(updateQuestion.class.getName()).log(Level.SEVERE, null, ex);
//    }
//}catch (NumberFormatException ex) {
//    // Handle the case where the entered ID is not a valid integer
//    JFrame ns = new JFrame();
//    ns.setAlwaysOnTop(true);
//    JOptionPane.showMessageDialog(ns, "Invalid Question ID", "Error", JOptionPane.ERROR_MESSAGE);
//}
        // Handle any SQL exceptions
        // Log the exception for debugging purposes
        


  
   
    }//GEN-LAST:event_jButton2ActionPerformed

    private void UQActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UQActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UQActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
             Uid.setText("");
                 UQ.setText("");
                 UO1.setText("");
                 UO2.setText("");
                 UO3.setText("");
                 UO4.setText("");
                 UA.setText("");
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

  Online_Quiz_System db = new Online_Quiz_System(); 
            
             String type = null;
                if(E1.isSelected()){
                        type="1";
                }
                else if (M2.isSelected()){
                    type="2";
                } else if(H3.isSelected()){
                type="3";
                
                }else{
                    JOptionPane.showMessageDialog(this, "Please select difficulty level for question!");
                }
                int uidValue = Integer.parseInt(Uid.getText());
              int status=db.UpdateQuestion(uidValue,UQ.getText(),UO1.getText(),UO2.getText(),UO3.getText(),UO4.getText(),UA.getText(),type);
                   
                  
                  
                     if (status==1){  
                        
                   JOptionPane.showMessageDialog(this, "update successfully", "Insert Alert", JOptionPane.INFORMATION_MESSAGE);
                     }                       
                         Uid.setText("");
                         UQ.setText("");
                         UO1.setText("");
                         UO2.setText("");
                         UO3.setText("");
                         UO4.setText("");
                         UA.setText("");
      
//      
//      Online_Quiz_System db = new Online_Quiz_System();
//      int questionIdToUpdate = Integer.parseInt(Uid.getText());
//String questionText = UQ.getText();
//String option1Text = UO1.getText();
//String option2Text = UO2.getText();
//String option3Text = UO3.getText();
//String option4Text = UO4.getText();
//String answerText = UA.getText();
//
//if (db.UpdateQuestion(questionIdToUpdate, questionText, option1Text, option2Text, option3Text, option4Text, answerText) == 1) {
//    JOptionPane.showMessageDialog(this, "Question is updated", "Updated", 1);
//    Uid.setText("");
//    UQ.setText("");
//    UO1.setText("");
//    UO2.setText("");
//    UO3.setText("");
//    UO4.setText("");
//    UA.setText("");
//} else {
//    JOptionPane.showMessageDialog(this, "Error in updating Question", "Error", 1);
//}

//
//
//int questionIdToUpdate = Integer.parseInt(Uid.getText());
//
//if (db.UpdateQuestion(questionIdToUpdate, UQ.getText(), UO1.getText(),UO1.getText(), UO1.getText(), UO1.getText(), UA.getText()) == 1) {
//    JOptionPane.showMessageDialog(this, "Question is updated", "Updated", 1);
//    Uid.setText("");
//    UQ.setText("");
//    UO1.setText("");
//    UO2.setText("");
//    UO3.setText("");
//    UO4.setText("");
//    UA.setText("");
//} else {
//    JOptionPane.showMessageDialog(this, "Error in updating Qeustion", "Error", 1);
//}
//// 
//
//  
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void E1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_E1ActionPerformed
        // TODO add your handling code here:
         String type="";
        if(E1.isSelected()){
            type="1";
        }  
           if(E1.isSelected())
        {
          M2.setSelected(false);
          H3.setSelected(false);
         
        }
    }//GEN-LAST:event_E1ActionPerformed

    private void M2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_M2ActionPerformed
        // TODO add your handling code here:
         String type="";
        if(M2.isSelected()){
            type="2";
        } 
         if(M2.isSelected())
        {
          E1.setSelected(false);
          H3.setSelected(false);
         
        }
    }//GEN-LAST:event_M2ActionPerformed

    private void H3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_H3ActionPerformed
        // TODO add your handling code here:
         String type="";
        if(E1.isSelected()){
            type="3";
        }  
        
        if(H3.isSelected())
        {
          E1.setSelected(false);
          M2.setSelected(false);
         
        }
    }//GEN-LAST:event_H3ActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(updateQuestion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(updateQuestion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(updateQuestion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(updateQuestion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new updateQuestion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton E1;
    private javax.swing.JRadioButton H3;
    private javax.swing.JRadioButton M2;
    private javax.swing.JTextField UA;
    private javax.swing.JTextField UO1;
    private javax.swing.JTextField UO2;
    private javax.swing.JTextField UO3;
    private javax.swing.JTextField UO4;
    private javax.swing.JTextField UQ;
    private javax.swing.JTextField Uid;
    private javax.swing.JLabel diffLvl;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
