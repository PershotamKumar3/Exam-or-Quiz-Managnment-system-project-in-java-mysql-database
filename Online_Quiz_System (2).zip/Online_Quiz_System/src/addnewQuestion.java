import javax.swing.JOptionPane;
import online_quiz_system.Online_Quiz_System;


/**
 *
 * @author HP
 */
public class addnewQuestion extends javax.swing.JFrame {

    /**
     * Creates new form addnewQuestion
     */
    public addnewQuestion() {
        initComponents();
       
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel10 = new javax.swing.JLabel();
        jSplitPane1 = new javax.swing.JSplitPane();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        Q = new javax.swing.JTextField();
        O1 = new javax.swing.JTextField();
        O2 = new javax.swing.JTextField();
        O4 = new javax.swing.JTextField();
        O3 = new javax.swing.JTextField();
        ans = new javax.swing.JTextField();
        save = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        qid = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel11 = new javax.swing.JLabel();
        E1 = new javax.swing.JRadioButton();
        M2 = new javax.swing.JRadioButton();
        H3 = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();

        jLabel10.setText("jLabel10");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAlwaysOnTop(true);
        setBackground(new java.awt.Color(255, 204, 0));
        setLocation(new java.awt.Point(150, 183));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Algerian", 1, 25)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Add Questions ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 290, 70));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Close_1.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 10, 60, 60));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 76, 1060, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 25)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Question ID");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 90, 150, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 25)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Question :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, 150, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Option :2");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Option :1");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, 130, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Option :3");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 270, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Option :4");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 310, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Answer :");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 350, -1, -1));

        Q.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        Q.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QActionPerformed(evt);
            }
        });
        getContentPane().add(Q, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 140, 700, 40));

        O1.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        O1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                O1ActionPerformed(evt);
            }
        });
        getContentPane().add(O1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 190, 700, 30));

        O2.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        getContentPane().add(O2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 230, 700, 30));

        O4.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        getContentPane().add(O4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 310, 700, 30));

        O3.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        getContentPane().add(O3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 270, 700, 30));

        ans.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        ans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ansActionPerformed(evt);
            }
        });
        getContentPane().add(ans, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 350, 700, 30));

        save.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/save.png"))); // NOI18N
        save.setText("save");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        getContentPane().add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 470, 150, 30));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/clear.png"))); // NOI18N
        jButton3.setText("clear");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 470, 150, 30));

        qid.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        qid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                qidActionPerformed(evt);
            }
        });
        getContentPane().add(qid, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 90, 80, 30));
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 190, -1, -1));
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, -1));

        E1.setBackground(new java.awt.Color(204, 204, 204));
        E1.setFont(new java.awt.Font("Tahoma", 1, 19)); // NOI18N
        E1.setText("Easy");
        E1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                E1ActionPerformed(evt);
            }
        });
        getContentPane().add(E1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 400, 80, 30));

        M2.setBackground(new java.awt.Color(204, 204, 204));
        M2.setFont(new java.awt.Font("Tahoma", 1, 19)); // NOI18N
        M2.setText("Medium");
        M2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                M2ActionPerformed(evt);
            }
        });
        getContentPane().add(M2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 400, -1, 30));

        H3.setBackground(new java.awt.Color(204, 204, 204));
        H3.setFont(new java.awt.Font("Tahoma", 1, 19)); // NOI18N
        H3.setText("Hard");
        H3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                H3ActionPerformed(evt);
            }
        });
        getContentPane().add(H3, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 401, 80, 30));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/home page (1).png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-130, 0, 1190, 540));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        adminhome.open=0;
        setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void QActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_QActionPerformed

    private void O1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_O1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_O1ActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        // TODO add your handling code here:
           Online_Quiz_System db = new  Online_Quiz_System();
            int status; 
                String type;
                if(E1.isSelected()){
                        type="1";
                }
                else if (M2.isSelected()){
                    type="2";
                } else{
                type="3";
                }
                //        Online_Quiz_System db=new Online_Quiz_System();
       status=db.AddQuestions(Integer.parseInt(qid.getText()),  Q.getText(), O1.getText(), O2.getText(), O3.getText(),O4.getText(),ans.getText(),type);
        if(status==1){
           
         JOptionPane.showMessageDialog(this, "Question is added", "Added", 1);
                qid.setText("");
                 Q.setText("");
                 O1.setText("");
                 O2.setText("");
                 O3.setText("");
                 O4.setText("");
                 ans.setText("");
           }else{
          JOptionPane.showMessageDialog(this, "Error in Question add", "Added", 1);
        } 
       
    }//GEN-LAST:event_saveActionPerformed

    private void qidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_qidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_qidActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
                 qid.setText("");
                 Q.setText("");
                 O1.setText("");
                 O2.setText("");
                 O3.setText("");
                 O4.setText(""); 
                 ans.setText("");    
         
    }//GEN-LAST:event_jButton3ActionPerformed

    private void ansActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ansActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ansActionPerformed

    private void M2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_M2ActionPerformed
        // TODO add your handling code here:
         String type="";
        if(M2.isSelected()){
         type="2";
        }
         if(M2.isSelected())
        {
          E1.setSelected(false);
          H3.setSelected(false);
         
        }
    }//GEN-LAST:event_M2ActionPerformed

    private void E1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_E1ActionPerformed
        // TODO add your handling code here:
         String type="";
        if(E1.isSelected()){
         type="1";
        }
         if(E1.isSelected())
        {
          M2.setSelected(false);
          H3.setSelected(false);
         
        }
    }//GEN-LAST:event_E1ActionPerformed

    private void H3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_H3ActionPerformed
        // TODO add your handling code here:
         String type="";
        if(H3.isSelected()){
         type="3";
        }
         if(H3.isSelected())
        {
          M2.setSelected(false);
          E1.setSelected(false);
         
        }
    }//GEN-LAST:event_H3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(addnewQuestion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(addnewQuestion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(addnewQuestion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(addnewQuestion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new addnewQuestion().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton E1;
    private javax.swing.JRadioButton H3;
    private javax.swing.JRadioButton M2;
    private javax.swing.JTextField O1;
    private javax.swing.JTextField O2;
    private javax.swing.JTextField O3;
    private javax.swing.JTextField O4;
    private javax.swing.JTextField Q;
    private javax.swing.JTextField ans;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTextField qid;
    private javax.swing.JButton save;
    // End of variables declaration//GEN-END:variables
}
