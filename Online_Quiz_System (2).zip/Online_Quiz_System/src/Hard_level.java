import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import online_quiz_system.Online_Quiz_System;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Hard_level extends javax.swing.JFrame {

   public String questionid = "21";
    public String answer;
    public int min = 0;
    public int sec = 0;
    public int marks = 0;
    Timer time;
    
    public void answercheck() {
    String studentAnswer = "";

    // Checking which radio button is selected
    if (a.isSelected()) {
        studentAnswer = a.getText().trim(); 
    } else if (b.isSelected()) {
        studentAnswer = b.getText().trim();
    } else if (c.isSelected()) {
        studentAnswer = c.getText().trim();
    } else if (d.isSelected()) {
        studentAnswer = d.getText().trim();
    }
     
   
    // Display updated marks
    if (studentAnswer.equalsIgnoreCase(answer.trim())) { 
        marks = marks + 1;
        jLabel12.setText(String.valueOf(marks));
       
    } else {
        System.out.println("Incorrect Answer. Marks: " + marks);
    }

    // Question number change
    int questionId1 = Integer.parseInt(questionid);
    questionId1 = questionId1 + 1;
    questionid = String.valueOf(questionId1);

    // Clear radio buttons
    a.setSelected(false);
    b.setSelected(false);
    c.setSelected(false);
    d.setSelected(false);

    // Last question hide next button
    if (questionid.equals("30")) {
        jButton1.setVisible(false);
    }
}
       public void question(){
           Online_Quiz_System db = new Online_Quiz_System();
      
       ResultSet rs=db.showqueation(questionid);
     
        try {
            if(rs.next()){

                jLabel10.setText(rs.getString("Q_id"));
                qquiz.setText(rs.getString("Q")+"");
                a.setText(rs.getString("Op_1")+"");
                b.setText(rs.getString("Op_2")+"");
                c.setText(rs.getString("Op_3")+"");
                d.setText(rs.getString("Op_4")+"");
                 answer = rs.getString("A_Q1");
            }} catch (SQLException ex) {
            Logger.getLogger(easylevel.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
      
    
    public void submit(){
           answercheck();
    String marks1 = String.valueOf(marks);

    Online_Quiz_System db = new Online_Quiz_System();

    try {
        // Assuming marks is an integer variable representing the user's score
        int marksValue = marks;

        // Call the smarks method to insert marks into the database
        if (db.smarks(marksValue) == 1) {
            JOptionPane.showMessageDialog(this, "Result added successfully");
        } else {
            JOptionPane.showMessageDialog(this, "Error in adding result");
        }

        setVisible(false);
        new quiz_result(marks1).setVisible(true);
//        JOptionPane.showMessageDialog(null, marks1);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Invalid marks format", "Error", JOptionPane.ERROR_MESSAGE);
    }

    }
//       answercheck();
//     String marks1=String.valueOf(marks);
//      setVisible(false);
//     new quiz_result(marks1).setVisible(true);
//     JOptionPane.showMessageDialog(null, marks1);            
//    }
    public Hard_level() {
        initComponents();
         Online_Quiz_System db = new Online_Quiz_System();
        
       ResultSet rs=db.showqueation(questionid);
     
        try {
            if(rs.next()){
                jLabel10.setText(rs.getString("Q_id"));
                qquiz.setText(rs.getString("Q")+"");
                a.setText(rs.getString("Op_1")+"");
                b.setText(rs.getString("Op_2")+"");
                c.setText(rs.getString("Op_3")+"");
                d.setText(rs.getString("Op_4")+"");
                 answer = rs.getString("A_Q1");
            }} catch (SQLException ex) {
            Logger.getLogger(easylevel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //timer
  
         setLocationRelativeTo(this);
 
          time = new Timer(1000, new ActionListener() {
              @Override
              public void actionPerformed(ActionEvent e) {
                 jLabel6.setText(String.valueOf(sec));
                 jLabel5.setText(String.valueOf(min));
//                   sec++;
               
              if(sec==60)
              {
                sec=0;
                min++;
             
                if(min==10)
              { 
                time.stop();
                answercheck();
                submit();
                
              }  
              }
              sec++;
              
            }
          
        });
          time.start();
    

    }

    

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        a = new javax.swing.JRadioButton();
        b = new javax.swing.JRadioButton();
        c = new javax.swing.JRadioButton();
        d = new javax.swing.JRadioButton();
        qquiz = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Algerian", 1, 40)); // NOI18N
        jLabel1.setText("welcome");

        jLabel2.setFont(new java.awt.Font("Bahnschrift", 1, 20)); // NOI18N
        jLabel2.setText("Total time");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 25)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 255, 102));
        jLabel3.setText("10 mint");

        jLabel4.setFont(new java.awt.Font("Bahnschrift", 1, 20)); // NOI18N
        jLabel4.setText("Time Taken");

        jLabel5.setBackground(new java.awt.Color(255, 102, 102));
        jLabel5.setFont(new java.awt.Font("Algerian", 1, 27)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 0, 0));
        jLabel5.setText("0");

        jLabel6.setFont(new java.awt.Font("Algerian", 1, 27)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 51, 51));
        jLabel6.setText("0");

        jLabel7.setFont(new java.awt.Font("Bahnschrift", 0, 20)); // NOI18N
        jLabel7.setText("Total Questions");

        jLabel8.setFont(new java.awt.Font("Algerian", 1, 25)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 255, 102));
        jLabel8.setText("10");

        jLabel9.setFont(new java.awt.Font("Bahnschrift", 0, 20)); // NOI18N
        jLabel9.setText("Question No :");

        jLabel10.setFont(new java.awt.Font("Algerian", 1, 27)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 51, 51));
        jLabel10.setText("00");

        jLabel11.setFont(new java.awt.Font("Bahnschrift", 0, 20)); // NOI18N
        jLabel11.setText("Your Marks");

        jLabel12.setFont(new java.awt.Font("Algerian", 1, 25)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 255, 0));
        jLabel12.setText("0");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(134, 134, 134)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel9))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel3))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(84, 87, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(8, 8, 8))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 150));

        a.setBackground(new java.awt.Color(255, 255, 255));
        a.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        a.setForeground(new java.awt.Color(51, 51, 51));
        a.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aActionPerformed(evt);
            }
        });
        getContentPane().add(a, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 250, 360, 40));

        b.setBackground(new java.awt.Color(255, 255, 255));
        b.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        b.setForeground(new java.awt.Color(51, 51, 51));
        b.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bActionPerformed(evt);
            }
        });
        getContentPane().add(b, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 320, 360, 40));

        c.setBackground(new java.awt.Color(255, 255, 255));
        c.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        c.setForeground(new java.awt.Color(51, 51, 51));
        c.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cActionPerformed(evt);
            }
        });
        getContentPane().add(c, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 390, 360, 40));

        d.setBackground(new java.awt.Color(255, 255, 255));
        d.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        d.setForeground(new java.awt.Color(51, 51, 51));
        d.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dActionPerformed(evt);
            }
        });
        getContentPane().add(d, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 460, 360, 40));

        qquiz.setBackground(new java.awt.Color(255, 255, 255));
        qquiz.setFont(new java.awt.Font("Arial", 1, 22)); // NOI18N
        qquiz.setForeground(new java.awt.Color(255, 255, 255));
        qquiz.setText("question demo?");
        getContentPane().add(qquiz, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, 740, 50));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204,100));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 800, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 410, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, 800, 410));

        jButton2.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/save.png"))); // NOI18N
        jButton2.setText("Submit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 600, -1, -1));

        jButton1.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Next_1.png"))); // NOI18N
        jButton1.setText("Next");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 600, 110, -1));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/home page (1).png"))); // NOI18N
        jLabel13.setText("jLabel13");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(-50, 150, 1051, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void aActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aActionPerformed
        // TODO add your handling code here:
        if(a.isSelected())
        {
            b.setSelected(false);
            c.setSelected(false);
            d.setSelected(false);
        }
    }//GEN-LAST:event_aActionPerformed

    private void bActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bActionPerformed
        // TODO add your handling code here:
        if(b.isSelected())
        {
            a.setSelected(false);
            c.setSelected(false);
            d.setSelected(false);
        }
    }//GEN-LAST:event_bActionPerformed

    private void cActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cActionPerformed
        // TODO add your handling code here:
        if(c.isSelected())
        {
            a.setSelected(false);
            b.setSelected(false);
            d.setSelected(false);
        }
    }//GEN-LAST:event_cActionPerformed

    private void dActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dActionPerformed
        // TODO add your handling code here:
        if(d.isSelected())
        {
            b.setSelected(false);
            c.setSelected(false);
            a.setSelected(false);
        }
    }//GEN-LAST:event_dActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (!(a.isSelected() || b.isSelected() || c.isSelected() || d.isSelected())) {

            JOptionPane.showMessageDialog(this, "Please select an option before proceeding.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        answercheck();
        question();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        int a=JOptionPane.showConfirmDialog(null,"Do You really want to submit","Select",JOptionPane.YES_NO_OPTION);
        if(a==0){
            answercheck();
            setVisible(false);
            new   quiz_result().setVisible(true);
            submit();

        }
    }//GEN-LAST:event_jButton2ActionPerformed

    
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Hard_level().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton a;
    private javax.swing.JRadioButton b;
    private javax.swing.JRadioButton c;
    private javax.swing.JRadioButton d;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel qquiz;
    // End of variables declaration//GEN-END:variables
}
