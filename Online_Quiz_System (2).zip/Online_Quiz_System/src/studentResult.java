
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import online_quiz_system.Online_Quiz_System;


public class studentResult extends javax.swing.JFrame {
ResultSet rst;
    /**
     * Creates new form studentResult
     */
    public studentResult() {
        initComponents();
            DefaultTableModel DC=(DefaultTableModel)marks.getModel();
        DC.setRowCount(0);
          Online_Quiz_System  Connection= new Online_Quiz_System ();
        ResultSet rst = Connection.showresult();
         try {
             while(rst.next()){
           String data[]={rst.getString("Name"),Integer.toString(rst.getInt("contact")),rst.getString("email"),Integer.toString(rst.getInt("marks"))};
                 DC.addRow(data);
             }    } catch (SQLException ex) {
             Logger.getLogger(studentResult.class.getName()).log(Level.SEVERE, null, ex);
         }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        marks = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        dfind = new javax.swing.JButton();
        dsearch = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAlwaysOnTop(true);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Algerian", 0, 35)); // NOI18N
        jLabel1.setText("All Student Results");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 26, -1, -1));

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Close_1.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 10, -1, 60));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 95, 1050, 0));

        marks.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "name", "contact", "email", "marks"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(marks);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 1050, 340));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        dfind.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        dfind.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        dfind.setText("search");
        dfind.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dfindActionPerformed(evt);
            }
        });
        getContentPane().add(dfind, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 140, 130, 30));

        dsearch.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        getContentPane().add(dsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 140, 120, 30));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 25)); // NOI18N
        jLabel5.setText("Filter By Marks");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 190, 30));
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 92, 1040, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/home page (1).png"))); // NOI18N
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, 540));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       adminhome.open=0;
        setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void dfindActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dfindActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            Online_Quiz_System db=new Online_Quiz_System();

            ResultSet rs;
            rs=db.marksSearch(dsearch.getText());
            DefaultTableModel tb=(DefaultTableModel)marks.getModel();
            tb.setRowCount(0);
            while(rs.next()){
                String data[]={rs.getString("Name"),Integer.toString(rs.getInt("contact")),rs.getString("email"),Integer.toString(rs.getInt("marks"))};                tb.addRow(data);

            }
        } catch (SQLException ex) {
            Logger.getLogger(studentResult.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_dfindActionPerformed

    /**
     * @param args the command line arguments
    */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(studentResult.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(studentResult.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(studentResult.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(studentResult.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new studentResult().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton dfind;
    private javax.swing.JTextField dsearch;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable marks;
    // End of variables declaration//GEN-END:variables
}
