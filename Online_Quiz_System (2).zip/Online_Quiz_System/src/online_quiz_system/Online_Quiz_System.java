
package online_quiz_system;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Online_Quiz_System {

    
    private  Connection con;
   private Statement st;
    private ResultSet rs;
    private Connection yourConnection;
    private PreparedStatement ss;
    private Object connection;
 
   
    
  
    public  Online_Quiz_System(){
        
        try{
          
          Class.forName("com.mysql.cj.jdbc.Driver");
          con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_quiz_system", "root","");
          st= con.createStatement();
          System.out.println("DB is Connected");
       
        }catch(Exception e){
         System.out.println(e);
        }
       
    }
    
  public ResultSet getquestions(){

   String sql="select * from q_add";
    try{
    rs=st.executeQuery(sql);
   }catch(SQLException e){
  
    System.out.println(e);
    }
  
     return rs;
  }

     
     
     public int AddStudent(String name,int phone,String email){
    int status=0;
        try {
            String sql="insert into s_signup values('"+name+"','"+phone+"','"+email+"')";
            status=st.executeUpdate(sql);
        } catch (SQLException ex) {
            System.out.println(ex);
        
        }
        
        
        return status;

   }
     
    public int Addresult(String name, int contact, String email ) {
    int status = 0;
    try {
        String sql = "INSERT INTO student_results (Name, contact, email) VALUES ('" + name + "', " + contact + ", '" + email + "')";
        status = st.executeUpdate(sql);
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return status;
}


     public int smarks(int marks ){
     int status=0;
        try {
            String sql="insert into student_results (marks) values ('" + marks + "')";//"insert into student_results values('"+marks+"')";
            status=st.executeUpdate(sql);
        } catch (SQLException ex) {
            System.out.println(ex);
        
        }
        
        
        return status;

   } 

  public int AddQuestions(int Q_id, String Q, String Op_1, String Op_2, String Op_3, String Op_4, String A_Q1, String type) {
    int status = 0;
    try {
        String sql = "INSERT INTO q_add VALUES ('" + Q_id + "','" + Q + "','" + Op_1 + "','" + Op_2 + "','" + Op_3 + "','" + Op_4 + "','" + A_Q1 + "','" + type + "')";
        status = st.executeUpdate(sql);
    } catch (SQLException ex) {
        System.out.println(ex);
    }
    return status;
}

    public ResultSet showqueation(String Q_id){
    
        try {
            String sql="SELECT * FROM `q_add` WHERE Q_id='"+Q_id+"'";
            rs=st.executeQuery(sql);
        } catch (SQLException ex) {
            System.out.println(ex);
        
        }
        return rs;
    

   }

   
    public int UpdateQuestion(int Uid, String UQ, String UO1, String UO2, String UO3, String UO4, String UA,String type) {
    int status = 0;
    try {
        String sql =  "update q_add set Q='" + UQ + "', Op_1='" + UO1 + "', Op_2='" + UO2 + "', Op_3='" + UO3 + "', Op_4='" + UO4 + "', A_Q1='" + UA + "',`type`='"+type+"' WHERE `Q_id`='"+Uid+"'"; 
        status = st.executeUpdate(sql);
    } catch (SQLException ex) {
        System.out.println(ex);
    }
    return status;
}
    
 public ResultSet DisplayAllQ(){

  String sql="select * from q_add";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  return rs;

}
 public ResultSet findAllQuestion(String searchdata){

        try {
            String sql="select * from q_add where Q_id='"+searchdata+"'";
            rs=st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Online_Quiz_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;
   
}
 public ResultSet DisplayAllD(){

  String sql="select * from q_add";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  return rs;

}   
 public ResultSet showresult(){

  String sql="select * from student_result";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  return rs;

}   
    
 public ResultSet findAllQuestiond(String searchdata){

        try {
            String sql="select * from q_add where Q_id='"+searchdata+"'";
            rs=st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Online_Quiz_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;
   
}   
public ResultSet marksSearch(String searchdata){

        try {
            String sql="select * from student_result where marks='"+searchdata+"'";
            rs=st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Online_Quiz_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;
   
}   
public ResultSet upquestion(String id) {
        try {
            String sql = "select * from q_add where Q_id='" + id + "'";
            rs = st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Online_Quiz_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }


public ResultSet DeleteQ(){

  String sql="select * from q_add";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  return rs;

}
public int DeleteBYID(String Q){
int s=0;
        try {
            String sql="delete from q_add  where Q='"+Q+"'";
            System.out.println(sql);
            s=st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Online_Quiz_System.class.getName()).log(Level.SEVERE, null, ex);
        }
     return s;
}

public ResultSet showMediumLevelQuestions() {
    try {
        // Assuming there's a 'type' column in your table that indicates the question type
        String sql = "SELECT * FROM q_add WHERE Q_id BETWEEN 11 AND 20 AND type = 'medium'";
        return st.executeQuery(sql);
    } catch (SQLException ex) {
        System.out.println(ex);
        return null;
    }
}



    public static void main(String[] args) {
        // TODO code application logic here
        Online_Quiz_System db=new Online_Quiz_System();
}

}
