
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import online_quiz_system.Online_Quiz_System;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class displaySD extends javax.swing.JFrame {
ResultSet rst;

    public displaySD() {
        initComponents();
         Online_Quiz_System  db = new Online_Quiz_System ();
         ResultSet rs;
        rs=db. DisplayAllQ();
      String type;

        try{
           while(rs.next()){
                 type = rs.getString("type");
        if ("1".equals(type)) {
            type = "easy";
        } else if ("2".equals(type)) {
            type = "medium";
        } else if ("3".equals(type)) {
            type = "hard";
        }
              String data[]={
                  rs.getString("Q_id"), rs.getString("Q"),rs.getString("Op_1"), rs.getString("Op_2"),rs.getString("Op_3"),rs.getString("Op_4"),rs.getString("A_Q1"),type };
              DefaultTableModel Model=(DefaultTableModel)allquestions.getModel();
              Model.addRow(data);
            }
        }catch(SQLException ex){
             Logger.getLogger(displaySD.class.getName()).log(Level.SEVERE, null, ex);
            
        }
 }
//    public displaySD() throws SQLException {
//        initComponents();
//        DefaultTableModel DC=(DefaultTableModel)allq.getModel();
//        DC.setRowCount(0);
//         Online_Quiz_System Connection=new Online_Quiz_System();
//        ResultSet rst = Connection.DisplayAllQ();
//                while(rst.next()){
//            String[] data ={rst.getString("Q_id"),rst.getString("Q"),rst.getString("Op_1"),rst.getString("Op_2"),rst.getString("Op_3"),rst.getString("Op_4"),rst.getString("A_Q1")};
//            DC.addRow(data);
//                }
//    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        allquestions = new javax.swing.JTable();
        search = new javax.swing.JTextField();
        find = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Algerian", 1, 35)); // NOI18N
        jLabel1.setText("All Questions ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 396, 97));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 0, 87, 113));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 1066, -1));

        allquestions.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Question", "Option1", "Option2", "Option3", "Option4", "Answer", "type"
            }
        ));
        jScrollPane1.setViewportView(allquestions);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 1070, 430));

        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        getContentPane().add(search, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 70, 120, 30));

        find.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        find.setText("Search ");
        find.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findActionPerformed(evt);
            }
        });
        getContentPane().add(find, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 70, 120, 30));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Close_1.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 10, 70, 60));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/home page (1).png"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1070, 540));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void findActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findActionPerformed
        // TODO add your handling code here:
    try {
         // TODO add your handling code here:
            Online_Quiz_System db=new Online_Quiz_System();
         
         ResultSet rs;
         rs=db.findAllQuestion(search.getText());
         DefaultTableModel tb=(DefaultTableModel)allquestions.getModel();
         tb.setRowCount(0);
         while(rs.next()){
             String[] data ={rs.getString("Q_id"),rs.getString("Q"),rs.getString("Op_1"),rs.getString("Op_2"),rs.getString("Op_3"),rs.getString("Op_4"),rs.getString("A_Q1"),rs.getString("type")};
             tb.addRow(data);
         
         }
     } catch (SQLException ex) {
         Logger.getLogger(displaySD.class.getName()).log(Level.SEVERE, null, ex);
     }
    }//GEN-LAST:event_findActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
             adminhome.open=0;
              setVisible(false);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(displaySD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(displaySD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(displaySD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(displaySD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new displaySD().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable allquestions;
    private javax.swing.JButton find;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField search;
    // End of variables declaration//GEN-END:variables

    
}
