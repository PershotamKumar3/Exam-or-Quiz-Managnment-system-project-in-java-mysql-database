-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2024 at 11:20 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_quiz_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `q_add`
--

CREATE TABLE `q_add` (
  `Q_id` varchar(17) NOT NULL,
  `Q` varchar(500) NOT NULL,
  `Op_1` varchar(500) NOT NULL,
  `Op_2` varchar(500) NOT NULL,
  `Op_3` varchar(500) NOT NULL,
  `Op_4` varchar(500) NOT NULL,
  `A_Q1` varchar(500) NOT NULL,
  `type` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `q_add`
--

INSERT INTO `q_add` (`Q_id`, `Q`, `Op_1`, `Op_2`, `Op_3`, `Op_4`, `A_Q1`, `type`) VALUES
('1', 'Who invented Java Programming?', 'Guido van Rossum', ' James Gosling', 'Dennis Ritchie', 'Bjarne Stroustrup', 'James Gosling', 1),
('10', 'Which environment variable is used to set the java path?', 'MAVEN_Path', 'JavaPATH', 'JAVA', ' JAVA_HOME', 'JAVA_HOME', 1),
('11', 'What is the purpose of the super keyword in Java?', ' Access superclass variables and methods', 'Invoke the subclass constructor', 'Create a new instance of a superclass', 'Declare a superclass variable', 'Access superclass variables and methods', 2),
('12', 'What is the purpose of the final keyword in Java?', 'Prevent a class from being extended', 'Make a variable constant', 'Mark a method as abstract', 'Allow a class to be subclassed', 'Prevent a class from being extended', 2),
('13', 'Which keyword is used to prevent method overriding in Java?', 'sealed', ' static', 'final', 'override', 'final', 2),
('14', 'What is the purpose of the volatile keyword in Java?', 'Ensure only one instance of a class ', 'Guarantee thread safety for a variable', 'Make a class thread-safe ', 'Prevent inheritance', 'Guarantee thread safety for a variable', 2),
('15', ' Which of the following is a superclass of every class in Java? ', 'ArrayList', 'Abstract class ', 'Object class ', ' String', 'Object class ', 2),
('16', 'Which of these packages contains the exception Stack Overflow in Java?', ' java.io ', 'java.system ', 'java.lang', ' java.util', 'java.lang', 2),
('17', 'Which of these keywords are used for the block to be examined for exceptions?', 'check ', 'throw ', 'catch', 'try', 'throw ', 2),
('18', ' Which one of the following is not an access modifier?', 'Protected ', ' Void', 'Public', ' Private', ' Void', 2),
('19', 'Which of these constructors is used to create an empty String object?', 'String()', 'String(void) ', 'String(0) ', ' None of these', 'String()', 2),
('20', 'Which of these class is superclass of String and StringBuffer class?', 'java.util', 'java.lang ', 'ArrayList ', ' None of these ', 'java.lang ', 2),
('21', 'What makes the Java platform independent?', 'Advanced programming language ', 'It uses bytecode for execution', 'Class compilation', ' All of these', 'It uses bytecode for execution', 3),
('22', 'What are the types of memory allocated in memory in java?  Heap memory', 'Heap memory ', 'Stack memory', 'Both A and B', 'None of these', 'Both A and B', 3),
('23', 'Multiline comment is created using ___. ', '// ', '/* */', ' <!--  -- >', 'none of these', '/* */', 2),
('24', ' What is the entry point of a program in Java?', 'main() method', 'The first line of code', 'Last line of code', ' main class', 'main() method', 3),
('26', 'Which class in Java is used to take input from the user?', 'Scanner ', 'Input', 'Applier ', 'None of these', 'Scanner ', 3),
('27', 'Method used to take a string as input in Java?', 'next() ', 'nextLine() ', 'Both A. and B', 'None of these', 'Both A. and B', 3),
('28', ' Which of these is a type of variable in Java?  ', 'Instance Variable ', ' Local Variable', 'Static Variable ', 'All of these', 'All of these', 3),
('29', 'Which type of casting is lossy in Java?', 'Widening typecasting ', 'Narrowing typecasting ', ' Manual typecasting ', ' All of these', 'Narrowing typecasting ', 3),
('3', 'Which of the following is a type of polymorphism in Java Programming?', 'Multiple polymorphism', ' Compile time polymorphism', 'Multilevel polymorphism', 'Execution time polymorphism', ' Compile time polymorphism', 1),
('33', 'whta', 'er', 'hgf', 'df', 'tr', 'er', 3),
('4', 'Which exception is thrown when java is out of memory?', 'MemoryError', 'OutOfMemoryError', ' MemoryOutOfBoundsException', 'MemoryFullException', 'OutOfMemoryError', 1),
('5', 'Which of the following is not an OOPS concept in Java?', 'Polymorphism', 'Inheritance', 'Compilation', ' Encapsulation', 'Compilation', 1),
('6', 'Which component is used to compile, debug and execute the java programs?', 'JRE', 'JIT', 'JDK', 'JVM', 'JDK', 1),
('7', '. Which of these cannot be used for a variable name in Java?', 'identifier & keyword', 'identifier', 'keyword', 'none of the mentioned', 'keyword', 1),
('8', 'Which of these are selection statements in Java?', ' break', 'continue', 'for()', ' if()', ' if()', 1),
('9', 'What is the extension of java code files?', '.js', '.txt', '.class', ' .java', '.java', 1);

-- --------------------------------------------------------

--
-- Table structure for table `student_result`
--

CREATE TABLE `student_result` (
  `Name` varchar(50) NOT NULL,
  `contact` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `marks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_result`
--

INSERT INTO `student_result` (`Name`, `contact`, `email`, `marks`) VALUES
('pershotam', 438326476, 'mpershotamkumar@gmail.com', 8),
('persh', 345346643, 'persh@gmail.com', 6),
('nitasha kumari ', 34567765, 'nia@', 6),
('sunjesh', 456765, 'sun@gmail.com', 7),
('pers', 5678, 'abc@gmail.com', 6);

-- --------------------------------------------------------

--
-- Table structure for table `student_results`
--

CREATE TABLE `student_results` (
  `Name` varchar(100) DEFAULT NULL,
  `contact` bigint(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `type` int(250) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_results`
--

INSERT INTO `student_results` (`Name`, `contact`, `email`, `type`, `marks`) VALUES
('pershotam', 345, 'mper', 0, 0),
('pershotam', 345, 'mper', 0, 0),
('pershotam', 345, 'mpersh', 0, 0),
('dfgh', 3456, 'mpert', NULL, NULL),
('persh', 3456, 'mpers', NULL, NULL),
(NULL, NULL, NULL, NULL, 5),
('pershotam', 345, 'mpers@', NULL, NULL),
(NULL, NULL, NULL, NULL, 5),
(NULL, NULL, NULL, NULL, 5),
(NULL, NULL, NULL, NULL, 0),
('persho', 5645, 'mpershotam', NULL, NULL),
('group', 345, 'mp', NULL, NULL),
('group', 45, 'tr', NULL, NULL),
('group', 4, 'mpp', NULL, NULL),
('group', 654, 'mper', NULL, NULL),
('grop', 234, 'euhfie', NULL, NULL),
(NULL, NULL, NULL, NULL, 1),
(NULL, NULL, NULL, NULL, 4),
(NULL, NULL, NULL, NULL, 3),
(NULL, NULL, NULL, NULL, 6),
(NULL, NULL, NULL, NULL, 6),
(NULL, NULL, NULL, NULL, 7),
(NULL, NULL, NULL, NULL, 6),
(NULL, NULL, NULL, NULL, 7),
(NULL, NULL, NULL, NULL, 3),
('', 0, '', 0, 0),
('', 0, '', 0, 0),
(NULL, NULL, NULL, NULL, 5),
(NULL, NULL, NULL, NULL, 5),
(NULL, NULL, NULL, NULL, 0),
(NULL, NULL, NULL, NULL, 7),
(NULL, NULL, NULL, NULL, 4),
(NULL, NULL, NULL, NULL, 4),
(NULL, NULL, NULL, NULL, 8),
(NULL, NULL, NULL, NULL, 9),
(NULL, NULL, NULL, NULL, 3),
(NULL, NULL, NULL, NULL, 6),
(NULL, NULL, NULL, NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `s_signup`
--

CREATE TABLE `s_signup` (
  `name` varchar(40) NOT NULL,
  `phone` bigint(13) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `s_signup`
--

INSERT INTO `s_signup` (`name`, `phone`, `email`) VALUES
('peshotam', 97897, 'prqjpijererr'),
('pershotm', 233333333, 'pershotamkumar634@gmail.com'),
('persh', 34434, 'mperhso@gmail.com'),
('perhsotam', 343434, 'mpershoram@gmail,com'),
('', 343434, ''),
('perxo', 23323, 'mpersjot@gmail.com'),
('persho', 2333, 'mpershotam@gmak'),
('pershotam', 3434, 'mpershtoam@gmail.com'),
('pere', 3344, 'mpersho@gmail.com'),
('perhso', 2323, 'mpershotam@gmail.com'),
('pere', 3344, 'mper@gmail.com'),
('pershotam', 23456, 'mper@gmail.com'),
('per', 3456, 'mper@gmil.com'),
('pershitam', 23, 'mpersjo@gmail.com'),
('gewde', 23, 'mperhtosm'),
('gftyfty', 354, 'khhk'),
('pershtoam', 2333, 'mpershsotam@gmail.com'),
('miraj ', 34343, 'miraj@gmail.com'),
('pershotsm', 233, 'mperhtoamgmail@.com'),
('ggr', 344, 'pesrsho@hao'),
('per', 334, 'mpersj@gmail.com'),
('pershotam', 3434343, ' per@gmail.com'),
('pershotam', 343832647, 'mpershotam@gmail.com'),
('pershotam', 343832647, 'mpershotam@gmail.com'),
('trty', 34, 'kjkj'),
('dfg', 34, 'fgh'),
('yu', 68, 'y77'),
('fe', 23, 'me'),
('fe', 34, 'fg'),
('lo', 5678, 'bkhgff'),
('er', 34, 'fe'),
('wer', 3444, 'mper@'),
('ert', 234, 'mper'),
('123', 234, 'kfme'),
('err', 34, 'mpers'),
('2344er', 345, 'melf'),
('efe', 34, 'dd'),
('erty', 34, 'mpt'),
('sf', 234, 'sdf'),
('pershtoam', 2332324, 'mpershotam@ku'),
('ert', 234, 'mj'),
('h', 456, 'kj'),
('ert', 345, 'cv'),
('er', 34, 'efr'),
('df', 34, 'pdf'),
('love', 345684162, 'loagedg'),
('per', 438326476, 'mpers'),
('per', 438326476, 'mpershotam@gmail.com'),
('pershotam', 234, 'mpersho'),
('persj', 34, 'cvb'),
('er', 34, 're'),
('per', 345, 'vf'),
('persjotam', 345, 'mpershtoam'),
('pershotam', 345, 'mpershotam@gmail,com'),
('pershotam', 2345, 'mpershotam@gmail.cpom'),
('pershot', 2345, 'perm@'),
('pershotam', 3456, 'pem'),
('poiuy', 456, 'mper'),
('pershotam', 343832647, 'mpershotam@gmail.com'),
('pershotam', 345, 'mpers@'),
('persho', 345, 'mper'),
('pershotam', 45, 'mpers'),
('pers', 345, 'mper'),
('pershotam', 345, 'mper'),
('perhs', 543, 'meprsho@'),
('pershotam', 345, 'mper'),
('pershotam', 345, 'mper'),
('pershotam', 345, 'mpersh'),
('pershotam', 3456, 'mpers'),
('dfgh', 3456, 'mpert'),
('persh', 3456, 'mpers'),
('pershotam', 345, 'mpers@'),
('persho', 5645, 'mpershotam'),
('group', 345, 'mp'),
('group', 45, 'tr'),
('group', 4, 'mpp'),
('group', 654, 'mper'),
('grop', 234, 'euhfie'),
('group', 567, 'mper'),
('group', 4567, 'mper'),
('group', 456, 'mper'),
('pers', 567, 'mper'),
('per', 543, 'mper'),
('per', 4567, 'mper'),
('per', 456, 're'),
('persho', 567, 'mper'),
('group', 345, 'mper@'),
('persh', 654, 'mper'),
('khl', 56789, 'dhflahfa'),
('group', 456, 'mper'),
('perrshotam', 438326576, 'mpersh'),
('pershotam', 56456767, 'mpers'),
('pershotam', 438326476, 'mpershotam@gmail.com'),
('per', 4567, 'mp'),
('group', 4567, 'mper'),
('xyz', 4567, 'mper'),
('group', 4567, 'mpersh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `q_add`
--
ALTER TABLE `q_add`
  ADD PRIMARY KEY (`Q_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
